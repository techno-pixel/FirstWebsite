function reply_click(clicked_id) {
      alert(clicked_id);
}
// code was inspired by https://stackoverflow.com/questions/4825295/javascript-onclick-to-get-the-id-of-the-clicked-button
