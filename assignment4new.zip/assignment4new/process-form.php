<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Book your group now!</title>
		<link href="https://fonts.googleapis.com/css?family=Satisfy&display=swap" rel="stylesheet">
		<link href="css/styles.css" rel="stylesheet">
	</head>
	<body>
		<header>
			<div>
				<h1>Fancy a party? Book here!</h1>
			</div>
			<img src="img/logo.jpg" alt="logo" height="125" width="125">
		</header>
		<main>
			<?php
				/* All form elements must be checked - that required information is present and that all form data
				is in the correct format. Security checks must also be made before database queries are made */
				$fname = $_GET['fname'];
				$lname = $_GET['lname'];
				// Output a friendly message to confirm that everything went well
				echo('<p class="message">Thank You, '.$fname.'&nbsp;'.$lname.', your booking has been confirmed! Please check your email</p>');
			?>
		</main>
		<footer>
			<p><small>2019 Excelsior Gaming™️. All rights reserved.</small></p>
		</footer>
	</body>
</html>
